import java.util.ArrayList;
import java.util.List;

class Bibliotheque {
    private List<Livre> livres;
    private List<Auteur> auteurs;
    private List<Emprunteur> emprunteurs;

    public Bibliotheque() {
        this.livres = new ArrayList<>();
        this.auteurs = new ArrayList<>();
        this.emprunteurs = new ArrayList<>();
    }



    // Méthodes pour les livres

    public void ajouterLivre(Livre livre)
    {
        livres.add(livre);
    }

    public void supprimerLivre(Livre livre)
    {
        livres.remove(livre);
    }

    public void modifierLivre(Livre livre, String titre, Auteur auteur, String datePublication, int numeroIdentification, boolean disponibilite) {
        livre.setTitre(titre);
        livre.setAuteur(auteur);
        livre.setDatePublication(datePublication);
        livre.setNumeroIdentification(numeroIdentification);
        livre.setDisponibilite(disponibilite);
    }

    public void afficherLivres() {
        System.out.println("Liste des livres :");
        for (Livre livre : livres) {
            System.out.println("- Titre : " + livre.getTitre());
            System.out.println("  Auteur : " + livre.getAuteur().getNom());
            System.out.println("  Date de publication : " + livre.getDatePublication());
            System.out.println("  Numéro d'identification : " + livre.getNumeroIdentification());
            System.out.println("  Disponibilité : " + (livre.isDisponibilite() ? "Disponible" : "Indisponible"));
        }
    }



    // Méthodes pour les auteurs

    public void ajouterAuteur(Auteur auteur) {
        auteurs.add(auteur);
    }

    public void supprimerAuteur(Auteur auteur) {
        auteurs.remove(auteur);
    }

    public void modifierAuteur(Auteur auteur, String nom, String dateNaissance, String nationalite) {
        auteur.setNom(nom);
        auteur.setDateNaissance(dateNaissance);
        auteur.setNationalite(nationalite);
    }

    public void afficherAuteurs() {
        System.out.println("Liste des auteurs :");
        for (Auteur auteur : auteurs) {
            System.out.println("- Nom : " + auteur.getNom());
            System.out.println("  Date de naissance : " + auteur.getDateNaissance());
            System.out.println("  Nationalité : " + auteur.getNationalite());
        }
    }



    // Méthodes pour les emprunteurs

    public void afficherEmprunteurs() {
        System.out.println("Liste des emprunteurs :");
        for (Emprunteur emprunteur : emprunteurs) {
            System.out.println("- Nom : " + emprunteur.getNom());
            System.out.println("  Adresse : " + emprunteur.getAdresse());
            System.out.println("  Numéro de téléphone : " + emprunteur.getNumeroTelephone());
        }
    }

    public void ajouterEmprunteur(Emprunteur emprunteur) {
        emprunteurs.add(emprunteur);
    }

    public void supprimerEmprunteur(Emprunteur emprunteur) {
        emprunteurs.remove(emprunteur);
    }

    public void modifierEmprunteur(Emprunteur emprunteur, String nom, String adresse, String numeroTelephone) {
        emprunteur.setNom(nom);
        emprunteur.setAdresse(adresse);
        emprunteur.setNumeroTelephone(numeroTelephone);
    }



    // Méthodes pour les emprunts

    public void emprunterLivre(int numeroIdentification, String nomEmprunteur) {
        Livre livre = rechercherLivreParNumero(numeroIdentification);
        Emprunteur emprunteur = rechercherEmprunteurParNom(nomEmprunteur);

        if (livre != null && emprunteur != null && livre.isDisponibilite()) {
            livre.setDisponibilite(false);
            System.out.println("Le livre \"" + livre.getTitre() + "\" a été emprunté par " + emprunteur.getNom());
        } else {
            System.out.println("Impossible d'emprunter le livre. Vérifiez le numéro d'identification et la disponibilité du livre, ainsi que le nom de l'emprunteur.");
        }
    }

    public void retournerLivre(int numeroIdentification) {
        Livre livre = rechercherLivreParNumero(numeroIdentification);

        if (livre != null && !livre.isDisponibilite()) {
            livre.setDisponibilite(true);
            System.out.println("Le livre \"" + livre.getTitre() + "\" a été retourné.");
        } else {
            System.out.println("Impossible de retourner le livre. Vérifiez le numéro d'identification et l'état d'emprunt du livre.");
        }
    }

    // Méthodes de recherche

    private Livre rechercherLivreParNumero(int numeroIdentification) {
        for (Livre livre : livres) {
            if (livre.getNumeroIdentification() == numeroIdentification) {
                return livre;
            }
        }
        return null;
    }

    private Emprunteur rechercherEmprunteurParNom(String nomEmprunteur) {
        for (Emprunteur emprunteur : emprunteurs) {
            if (emprunteur.getNom().equals(nomEmprunteur)) {
                return emprunteur;
            }
        }
        return null;
    }
}
