class Auteur {
    private String nom;
    private String dateNaissance;
    private String nationalite;

    public Auteur(String nom, String dateNaissance, String nationalite) {
        this.nom = nom;
        this.dateNaissance = dateNaissance;
        this.nationalite = nationalite;
    }

    // Getters et setters

    public String getNom() {
        return nom;
    }
    public String getDateNaissance() {
        return dateNaissance;
    }
    public String getNationalite() {
        return nationalite;
    }



    public void setNom(String nom) {
        this.nom = nom;
    }
    public void setDateNaissance(String dateNaissance) {
        this.dateNaissance = dateNaissance;
    }
    public void setNationalite(String nationalite) {
        this.nationalite = nationalite;
    }
}
