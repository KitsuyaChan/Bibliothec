class Livre {
    private String titre;
    private Auteur auteur;
    private String datePublication;
    private int numeroIdentification;
    private boolean disponibilite;

    public Livre(String titre, Auteur auteur, String datePublication, int numeroIdentification, boolean disponibilite) {
        this.titre = titre;
        this.auteur = auteur;
        this.datePublication = datePublication;
        this.numeroIdentification = numeroIdentification;
        this.disponibilite = disponibilite;
    }

    // Getters et setters

    public String getTitre() {
        return titre;
    }
    public Auteur getAuteur() {
        return auteur;
    }
    public String getDatePublication() {
        return datePublication;
    }
    public int getNumeroIdentification() {
        return numeroIdentification;
    }
    public boolean isDisponibilite() {
        return disponibilite;
    }


    public void setTitre(String titre) {
        this.titre = titre;
    }
    public void setAuteur(Auteur auteur) {
        this.auteur = auteur;
    }
    public void setDatePublication(String datePublication) {
        this.datePublication = datePublication;
    }
    public void setNumeroIdentification(int numeroIdentification) {
        this.numeroIdentification = numeroIdentification;
    }
    public void setDisponibilite(boolean disponibilite) {
        this.disponibilite = disponibilite;
    }
}
