class Emprunteur {
    private String nom;
    private String adresse;
    private String numeroTelephone;

    public Emprunteur(String nom, String adresse, String numeroTelephone) {
        this.nom = nom;
        this.adresse = adresse;
        this.numeroTelephone = numeroTelephone;
    }

    // Getters et setters

    public String getNom() {
        return nom;
    }
    public String getAdresse() {
        return adresse;
    }
    public String getNumeroTelephone() {
        return numeroTelephone;
    }



    public void setNom(String nom) {
        this.nom = nom;
    }
    public void setAdresse(String adresse) {
        this.adresse = adresse;
    }
    public void setNumeroTelephone(String numeroTelephone) {
        this.numeroTelephone = numeroTelephone;
    }
}
