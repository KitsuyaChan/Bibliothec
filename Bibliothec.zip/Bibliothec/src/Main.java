import java.util.ArrayList;
import java.util.List;

public class Main {
    public static void main(String[] args) {
        Bibliotheque bibliotheque = new Bibliotheque();

        // On ajoute les auteurs
        Auteur auteur1 = new Auteur("J R Tolkien", "03/01/1982", "UK");
        bibliotheque.ajouterAuteur(auteur1);

        Auteur auteur2 = new Auteur("Rick Riordan", "05/06/1964", "USA");
        bibliotheque.ajouterAuteur(auteur2);



        // On ajoute les livres
        Livre livre1 = new Livre("Titre 1", auteur1, "01/01/2022", 1, true);
        bibliotheque.ajouterLivre(livre1);



        Livre livre2 = new Livre("Titre 2", auteur2, "05/06/2020", 2, true);
        bibliotheque.ajouterLivre(livre2);



        // On ajoute les emprunteurs
        Emprunteur emprunteur1 = new Emprunteur("Emprunteur 1", "Adresse 1", "123456789");
        bibliotheque.ajouterEmprunteur(emprunteur1);



        Emprunteur emprunteur2 = new Emprunteur("Emprunteur 2", "Adresse 2", "987654321");
        bibliotheque.ajouterEmprunteur(emprunteur2);



        // On affiche la liste des livres, auteurs et emprunteurs
        bibliotheque.afficherLivres();
        bibliotheque.afficherAuteurs();
        bibliotheque.afficherEmprunteurs();



        // Permet d'emprunter un livre
        bibliotheque.emprunterLivre(1, "Emprunteur 1");



        // On permet de retourner un livre
        bibliotheque.retournerLivre(1);



        // On modifie les informations d'un livre
        bibliotheque.modifierLivre(livre1, "Nouveau titre", auteur2, "10/10/2023", 1, true);



        // Afficher à nouveau la liste des livres
        bibliotheque.afficherLivres();
    }
}
